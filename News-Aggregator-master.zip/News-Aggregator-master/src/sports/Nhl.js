import React from 'react';
import SportsScores from './SportsScores.js';

class Nhl extends React.Component{
	render(){
		return(
			<div style={{backgroundColor:'purple', height:'100vh', width:'100vw'}}>
						<SportsScores />
			<h1>HI</h1><h1>HI</h1><h1>HI</h1><h1>HI</h1><h1>HI</h1>
			</div>
		)
	}
}


export default Nhl;